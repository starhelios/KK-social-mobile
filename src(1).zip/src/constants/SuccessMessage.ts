export const SUCCESS_MESSAGE = {
  USER_CREATED: 'User has been created.',
};
