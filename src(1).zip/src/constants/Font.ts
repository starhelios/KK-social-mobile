export const FONT = {
  AN_Regular: 'AvenirNextLTPro-Regular',
  AN_Bold: 'AvenirNextLTPro-Bold',
  AN_Italic: 'AvenirNextLTPro-It',
};
