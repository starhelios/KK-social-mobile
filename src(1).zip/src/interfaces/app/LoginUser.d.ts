import { ITokens, IUser } from ".";

export interface ILoginUser {
	user: IUser;
	tokens: ITokens;
}
