export interface IBank {
	name: string;
	number: string;
}
