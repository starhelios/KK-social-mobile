export interface ICard {
	number: string;
}
