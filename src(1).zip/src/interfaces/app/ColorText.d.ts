export interface IColorText {
	title: string;
	color: string;
	fontFamily: string;
	fontSize: number;
}
