export interface IFile {
	name: string,
    type: string,
	uri: string,
}
