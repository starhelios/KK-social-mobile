export interface ICategory {
	id: string,
	name: string,

	// test
	icon: string,
}
