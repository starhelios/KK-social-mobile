export interface IUser {
	id: string;
	fullname: string;
	status: string;
	email: string;
	isHost: boolean;

	image: string;
	birthday: string;
}
