const svg = `
<svg width="77" height="77" viewBox="0 0 77 77" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect opacity="0.253392" x="1" y="1" width="75" height="75" rx="15" stroke="#2A2A29" stroke-width="1.5" stroke-linejoin="round" stroke-dasharray="10 10"/>
</svg>
`;

export default svg;
