const svg = `
<svg width="32" height="4" viewBox="0 0 32 4" fill="none" xmlns="http://www.w3.org/2000/svg">
<path opacity="0.75" d="M0 0H32V2C32 3.10457 31.1046 4 30 4H2C0.895431 4 0 3.10457 0 2V0Z" fill="#E41E35"/>
</svg>
`;

export default svg;
