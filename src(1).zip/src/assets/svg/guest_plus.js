const svg = `
<svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect width="34" height="34" rx="17" fill="#2A2A29"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M16.2479 17.746H12.4099C11.4258 17.746 11.4329 16.2488 12.4169 16.2488L16.2549 16.2488L16.2549 12.4109C16.2549 11.4268 17.7451 11.4268 17.7451 12.4109L17.7451 16.2488L21.5831 16.2488C22.5671 16.2488 22.5742 17.746 21.5901 17.746H17.7521L17.7521 21.584C17.7521 22.5681 16.2479 22.5681 16.2479 21.584L16.2479 17.746Z" fill="#EAEAEA"/>
</svg>
`;

export default svg;
