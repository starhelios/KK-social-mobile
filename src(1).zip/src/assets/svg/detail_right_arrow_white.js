const svg = `
<svg width="6" height="12" viewBox="0 0 6 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<g opacity="0.5">
<path fill-rule="evenodd" clip-rule="evenodd" d="M4.60718 6L1.16898 2.11333C0.943674 1.85864 0.943674 1.44571 1.16898 1.19102C1.39428 0.936328 1.75957 0.936328 1.98487 1.19102L5.83102 5.53884C5.94367 5.66619 6 5.83309 6 6C6 6.16691 5.94367 6.33381 5.83102 6.46116L1.98487 10.809C1.75957 11.0637 1.39428 11.0637 1.16898 10.809C0.943674 10.5543 0.943674 10.1414 1.16898 9.88667L4.60718 6Z" fill="white" stroke="white" stroke-width="0.625"/>
</g>
</svg>
`;

export default svg;
