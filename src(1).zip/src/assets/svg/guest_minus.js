const svg = `
<svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
<g opacity="0.25">
<rect width="34" height="34" rx="17" fill="#2A2A29"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M16.2479 17.746H12.4099C11.4258 17.746 11.4329 16.2488 12.4169 16.2488L16.2549 16.2488H17.7451L21.5831 16.2488C22.5671 16.2488 22.5742 17.746 21.5901 17.746H17.7521H16.2479Z" fill="#EAEAEA"/>
</g>
</svg>
`;

export default svg;
